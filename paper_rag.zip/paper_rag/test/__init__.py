"""Lightweight project eval helpers."""
