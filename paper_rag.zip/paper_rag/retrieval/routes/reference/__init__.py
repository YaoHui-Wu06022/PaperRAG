"""Reference planning domain placeholder."""
