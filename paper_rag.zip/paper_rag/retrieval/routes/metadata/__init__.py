"""Metadata planning domain."""
